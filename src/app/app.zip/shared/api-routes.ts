import {environment} from "../../environments/environment";

const BASE_API_URL = environment.apiUrl;

export const API_ROUTES = {
  AUTH: {
    SIGNIN: `${BASE_API_URL}/account/login`,
    SIGNUP: `${BASE_API_URL}/account/register`,
  },
  TASK: {
    BASE: `${BASE_API_URL}/task`,
    GET_TASKS: `${BASE_API_URL}/task`,
    GET_TASKS_BY_USER: (userId: string) => `${BASE_API_URL}/task`,
    POST_TASK: `${BASE_API_URL}/task`,
    PUT_TASK: (taskId: string) => `${BASE_API_URL}/task`,
    DELETE_TASK: (taskId: string) => `${BASE_API_URL}/task`,
  },
};
