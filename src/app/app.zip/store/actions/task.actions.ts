import {createAction, props} from '@ngrx/store';
import {TaskModel} from '../models/task.model';

import {
  TaskDeleteFailed,
  TaskDeleteRequest,
  TaskDeleteSuccess,
  TaskPostFailed,
  TaskPostRequest,
  TaskPostSuccess,
  TaskPutFailed,
  TaskPutRequest,
  TaskPutSuccess,
  LoadTasks,
  LoadTasksSuccess,
  LoadTasksFailure
} from '../const/task.const';

export const loadTasks = createAction(LoadTasks);
export const loadTasksSuccess = createAction(LoadTasksSuccess, props<{ tasks: TaskModel[] }>());
export const loadTasksFailure = createAction(LoadTasksFailure, props<{ error: any }>());

export const postTaskRequest = createAction(TaskPostRequest, props<{ task: TaskModel }>());
export const postTaskSuccess = createAction(TaskPostSuccess, props<{ task: TaskModel }>());
export const postTaskFailure = createAction(TaskPostFailed, props<{ error: any }>());

export const putTaskRequest = createAction(TaskPutRequest, props<{ task: TaskModel }>());
export const putTaskSuccess = createAction(TaskPutSuccess, props<{ task: TaskModel }>());
export const putTaskFailure = createAction(TaskPutFailed, props<{ error: any }>());

export const deleteTaskRequest = createAction(TaskDeleteRequest, props<{ task: TaskModel }>());
export const deleteTaskSuccess = createAction(TaskDeleteSuccess, props<{ task: TaskModel }>());
export const deleteTaskFailure = createAction(TaskDeleteFailed, props<{ error: any }>());
