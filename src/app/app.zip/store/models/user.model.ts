export interface UserModel {
  userId: string;
  username: string;
  name: string;
  lastname: string;
  email: string;
  token: string;
}
