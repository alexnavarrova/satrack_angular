import {Injectable} from '@angular/core';
import {Actions, createEffect, ofType} from '@ngrx/effects';
import {of} from 'rxjs';
import {catchError, map, mergeMap, tap, switchMap} from 'rxjs/operators';

import {
  deleteTaskRequest,
  postTaskRequest,
  postTaskSuccess,
  putTaskRequest,
  putTaskSuccess,
  deleteTaskSuccess,
  loadTasks,
  loadTasksSuccess,
  loadTasksFailure,
} from '../actions/task.actions';

import {SnackbarService} from "../../utils/snackbar.service";
import { TaskService } from '../../services/task.service';

@Injectable()
export class TaskEffects {

  constructor(
    private actions$: Actions,
    private snackbarService: SnackbarService,
    private taskService: TaskService) {
  }

  private handleError = (error: any) => {
    return of(loadTasksFailure({error}));
  };

  loadTasks$ = createEffect(() =>
    this.actions$.pipe(
      ofType(loadTasks),
      mergeMap(() =>
        this.taskService.getTasks().pipe(
          map(tasks => {
            return loadTasksSuccess({ tasks });
          }),
          catchError(error => of(loadTasksFailure({ error })))
        )
      )
    )
  );

  postTaskRequest$ = createEffect(() =>
    this.actions$.pipe(
      ofType(postTaskRequest),
      mergeMap((action) =>
        this.taskService.postTask(action.task).pipe(
          map((task) => postTaskSuccess({task})),
          catchError((error) => {
            this.snackbarService.showError('Failed to create task');
            return of(loadTasksFailure({error}));
          })
        )
      )
    )
  );

  putTaskRequest$ = createEffect(() =>
    this.actions$.pipe(
      ofType(putTaskRequest),
      mergeMap((action) =>
        this.taskService.putTask(action.task).pipe(
          map((task) => putTaskSuccess({task})),
          catchError((error) => {
            this.snackbarService.showError('Failed to update task');
            return of(loadTasksFailure({error}));
          })
        )
      )
    )
  );

  deleteTaskRequest$ = createEffect(() =>
    this.actions$.pipe(
      ofType(deleteTaskRequest),
      tap((action) => console.info('Action received:', action)),
      mergeMap((action) =>
        this.taskService.deleteTask(action.task).pipe(
          map(() => deleteTaskSuccess({task: action.task})),
          catchError((error) => {
            this.snackbarService.showError('Failed to delete task');
            return of(loadTasksFailure({error}));
          })
        )
      )
    )
  );

  // refreshTasks$ = createEffect(() =>
  //   this.actions$.pipe(
  //     ofType(postTaskSuccess, putTaskSuccess, deleteTaskSuccess), // Listen for specific success actions
  //     switchMap(() => {
  //       return [
  //         getTaskByUserRequest(), // Dispatch action to get tasks by user after saving task
  //         getAllTaskRequest() // Refresh all tasks
  //       ]
  //     })// Dispatch getAllTaskRequest action after specific success actions
  //   )
  //);
}
