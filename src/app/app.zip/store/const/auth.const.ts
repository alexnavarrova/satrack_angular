export const SignInRequest = "[SignIn] Load auth";
export const SignInSuccess = "[SignIn] Load Auth Success";
export const SignInFailed = "[SignIn] Load Auth Failed";

export const SignUpRequest = "[SignUp] Load auth";
export const SignUpSuccess = "[SignUp] Load Auth Success";
export const SignUpFailed = "[SignUp] Load Auth Failed";
