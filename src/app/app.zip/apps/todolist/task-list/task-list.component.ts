import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { TaskModel } from '../../../store/models/task.model';
import { TaskState } from '../../../store/state/task-user.state';
import { Store } from '@ngrx/store';
import { selectAllTasks, selectTaskLoading, selectTaskError } from '../../../store/selectors/task.selectors';


@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html'
})
export class TaskListComponent {


  tasks$: Observable<TaskModel[]> = new Observable<TaskModel[]>();
  loading$: Observable<boolean> = new Observable<false>();

  error$!: Observable<any>;

  constructor(private store: Store<TaskState> ) {
    // this.tasks$ = this.store.select(selectTasksUser);
    // this.loading$ = this.store.select(selectTasksLoading);

    // console.log(this.loading$)
  }

   ngOnInit(): void {
    this.tasks$ = this.store.select(selectAllTasks);

    this.loading$ = this.store.select(selectTaskLoading);

    this.error$ = this.store.select(selectTaskError);

    console.log(this.loading$)
  }

}
