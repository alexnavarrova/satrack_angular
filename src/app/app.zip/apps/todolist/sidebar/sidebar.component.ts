import { Component } from '@angular/core';
import { TaskModel } from '../../../store/models/task.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html'
})
export class SidebarComponent {
  constructor(public fb: FormBuilder) {}
  selectedTab = '';
  isShowTaskMenu = false;
  searchTask = '';
  filteredTasks: any = [];
  pagedTasks: any = [];
  params!: FormGroup;
  allTasks : TaskModel[] = [];

  pager = {
    currentPage: 1,
    totalPages: 0,
    pageSize: 10,
    startIndex: 0,
    endIndex: 0,
  };

  initForm() {
    this.params = this.fb.group({
        id: [null],
        title: ['', Validators.required],
        description: [''],
        descriptionText: [''],
        assignee: [''],
        path: [''],
        tag: [''],
        priority: ['low'],
    });
}

  tabChanged(type: any = null) {
    this.selectedTab = type;
    this.searchTasks();
    this.isShowTaskMenu = false;

    }

  searchTasks(isResetPage = true) {
    if (isResetPage) {
        this.pager.currentPage = 1;
    }
    let res;
    if (this.selectedTab === 'complete' || this.selectedTab === 'important' || this.selectedTab === 'trash') {
        res = this.allTasks.filter((d) => d.categoryId === this.selectedTab);
    } else {
        res = this.allTasks.filter((d) => d.categoryId != 'trash');
    }

    if (this.selectedTab === 'team' || this.selectedTab === 'update') {
        res = res.filter((d) => d.categoryId === this.selectedTab);
    } else if (this.selectedTab === 'high' || this.selectedTab === 'medium' || this.selectedTab === 'low') {
        res = res.filter((d) => d.categoryId === this.selectedTab);
    }
    this.filteredTasks = res.filter((d) => d.title?.toLowerCase().includes(this.searchTask));
    this.getPager();
  }

  getPager() {
    setTimeout(() => {
        if (this.filteredTasks.length) {
            this.pager.totalPages = this.pager.pageSize < 1 ? 1 : Math.ceil(this.filteredTasks.length / this.pager.pageSize);
            if (this.pager.currentPage > this.pager.totalPages) {
                this.pager.currentPage = 1;
            }
            this.pager.startIndex = (this.pager.currentPage - 1) * this.pager.pageSize;
            this.pager.endIndex = Math.min(this.pager.startIndex + this.pager.pageSize - 1, this.filteredTasks.length - 1);
            this.pagedTasks = this.filteredTasks.slice(this.pager.startIndex, this.pager.endIndex + 1);
        } else {
            this.pagedTasks = [];
            this.pager.startIndex = -1;
            this.pager.endIndex = -1;
        }
    });
  }

  getTasksLength(type: string) {
    return this.allTasks.filter((task) => task.categoryId == type).length;
  }

  addEditTask(task: any = null) {
    this.isShowTaskMenu = false;


    this.initForm();

    if (task) {
        this.params.setValue({
            id: task.id,
            title: task.title,
            description: task.description,
            descriptionText: task.descriptionText,
            assignee: task.assignee,
            path: task.path,
            tag: task.tag,
            priority: task.priority,
        });
    }
}
}
