import { Component } from '@angular/core';
import { TaskState } from '../../../store/state/task-user.state';
import { Store } from '@ngrx/store';
import { loadTasks } from '../../../store/actions/task.actions';
import { Observable } from 'rxjs';
import { TaskModel } from '../../../store/models/task.model';
import { selectAllTasks, selectTaskError, selectTaskLoading } from '../../../store/selectors/task.selectors';


@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html'
})

export class TodoComponent {
  isShowTaskMenu = false;

    tasks$: Observable<TaskModel[]>;
    loading$: Observable<boolean>;
    error$: Observable<any>;

    constructor(private store: Store<{ taskState: TaskState }>) {
      this.tasks$ = this.store.select(selectAllTasks);
      this.loading$ = this.store.select(selectTaskLoading);
      this.error$ = this.store.select(selectTaskError);
    }

  ngOnInit(): void {
    this.store.dispatch(loadTasks());
  }
}
