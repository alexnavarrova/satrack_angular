import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SidebarComponent } from './sidebar/sidebar.component';
import { TaskListComponent } from './task-list/task-list.component';
import { TaskItemComponent } from './task-item/task-item.component';
import { TaskFormComponent } from './task-form/task-form.component';
import { TaskHeaderComponent } from './task-header/task-header.component';
import { TodoComponent } from './todo/todo.component';
import { IconModule } from '../../shared/icon/icon-module';
import { NgScrollbarModule } from 'ngx-scrollbar';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({

  declarations: [
    SidebarComponent,
    TaskListComponent,
    TaskItemComponent,
    TaskFormComponent,
    TaskHeaderComponent,
    TodoComponent,
  ],
  imports: [
    CommonModule,
    IconModule,
    NgScrollbarModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  exports: [
    TodoComponent
  ]
})
export class TodoListModule { }
